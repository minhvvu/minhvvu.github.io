#include <iostream>
// #include <vector>
// #include <utility>

#include <eigen3/Eigen/Dense>
using namespace Eigen;

class Hungarian {
public:
	Hungarian(int rows, int cols) : nRows(rows), nCols(cols) {
		X = MatrixXf(nRows, nCols);
	}

	Hungarian(const MatrixXf& data) {
		X = data;
		nRows = data.rows();
		nCols = data.cols();
	}

	void doOptimize() {	
		step1_subtract_min_row();
		step2_subtract_min_col();
		int nLines = step3_cover_zeros();
		int nControl = 0;
		while (nLines < nRows) {
			step4_add_zeros();
			nLines = step3_cover_zeros();

			nControl++;
			if (nControl > 100) {
				std::cout << "Code fail\n";
				break;
			}
		}
		step5_optimize();
	}

private:
	void step1_subtract_min_row() {
		X.colwise() -= X.rowwise().minCoeff();
		std::cout << "STEP 1: subtract row min:\n" << X << '\n';
	}

	void step2_subtract_min_col() {
		X.rowwise() -= X.colwise().minCoeff();
		std::cout << "STEP 2: subtract col min:\n" << X << '\n';
	}

	int step3_cover_zeros() {
		// X.resize(5, 5);
		// X << 
		// 	0,   1,   0,   1,   1,   
		// 	1,   1,   0,   1,   1,   
		// 	1,   0,   0,   0,   1,   
		// 	1,   1,   0,   1,   1,   
		// 	1,   0,   0,   1,   0 ;
		// nRows = 5;
		// nCols = 5;

		MatrixXf mask(nRows, nCols);
		mask.setZero();

		for (int r = 0; r < nRows; ++r) {
			for (int c = 0; c < nCols; ++c) {
				if (0 == X(r, c)) {
					int nZeroHor = nRows - (X.row(r)).count();
					int nZeroVer = nCols - (X.col(c)).count();
					if (nZeroHor > nZeroVer) {
						mask(r, c) = nZeroHor * horizontalDir;
					} else {
						mask(r, c) = nZeroVer * verticalDir;
					}
				}
			}
		}

		std::cout << "Step3_1: Mask : \n" << mask << '\n';
		
		MatrixXf linesVer(nRows, nCols);
		linesVer.setZero();
		int nLinesVer = 0;
		for (int c = 0; c < nCols; ++c) {
			for (int r = 0; r < nRows; ++r) {
				if (mask(r, c) > 0) { // line vertical
					linesVer.col(c).setOnes();
					mask.col(c).setZero();
					nLinesVer ++;
				}
			}
		}

		MatrixXf linesHor(nRows, nCols);
		linesHor.setZero();
		int nLinesHor = 0;
		for (int r = 0; r < nRows; ++r) {
			for (int c = 0; c < nCols; ++c) {
				if (mask(r, c) < 0) { //line horizontal
					linesHor.row(r).setOnes();
					mask.row(r).setZero();
					nLinesHor ++;
				}
			}
		}

		linesMask = linesHor + linesVer;
		int nLines = nLinesHor + nLinesVer;

		std::cout << "Step3_2: AllLines: \n" << linesMask << '\n';
		std::cout << "nLines = " << nLines << '\n';

		return nLines;
	}

	void step4_add_zeros() {
		float minRest = 99999;
		for (int r = 0; r < nRows; ++r) {
			for (int c = 0; c < nCols; ++c) {
				if (0 == linesMask(r, c)) {
					minRest = std::min(minRest, X(r, c));
				}
			}
		}
		std::cout << "Step4: minRest = " << minRest << '\n';

		for (int r = 0; r < nRows; ++r) {
			for (int c = 0; c < nCols; ++c) {
				if (0 == linesMask(r, c)) {
					X(r, c) -= minRest;
				} else if (2 == linesMask(r, c)) {
					X(r, c) += minRest;
				}
			}
		}

		std::cout << "Step4: Add zeros:\n" << X << '\n';
	}

	void step5_optimize() {
		rowAssignment = RowVectorXf::Zero(nCols);
		columnAssigned = VectorXf::Zero(nRows);

		step5_optimize_recusive(0);

		std::cout << "Step 5 : Optimize: \n" << rowAssignment << '\n';
	}

	bool step5_optimize_recusive(int forRow) {
		if (nRows == forRow) return true;

		bool isSuccessfull = false;
		for (int col = 0; col < nCols; ++col) {
			if (0 == X(forRow, col) && (0 == columnAssigned[col]) ) {
				rowAssignment[forRow] = col;
				columnAssigned[col] = 1;

				if (step5_optimize_recusive(forRow + 1)) {
					isSuccessfull = true;
				} else {
					isSuccessfull = false;
					columnAssigned[col] = 0;					
				}
			}
		}
		return isSuccessfull;
	}

public:
	int nRows;
	int nCols;

	MatrixXf X;
	MatrixXf linesMask;
	RowVectorXf rowAssignment;
	VectorXf columnAssigned;

	static const int horizontalDir = -1; // line nam ngang
	static const int verticalDir = 1;	  // line nam doc
};

int main() {
	std::cout << "Hungarian Algo\n";
	int nRows = 10;
	int nCols = 10;
	MatrixXf X(nRows, nCols);
	X << 
15 ,26 ,6 ,18 ,70 ,51 ,58 ,81 ,57 ,32,
32 ,84 ,3 ,90 ,90 ,68 ,45 ,78 ,98 ,1,
42 ,99 ,88 ,14 ,82 ,25 ,28 ,5 ,29 ,79,
19 ,40 ,16 ,93 ,42 ,31 ,76 ,11 ,43 ,58,
55 ,13 ,34 ,52 ,9 ,13 ,92 ,83 ,56 ,74,
50 ,23 ,67 ,63 ,54 ,55 ,5 ,72 ,85 ,54,
36 ,96 ,30 ,1 ,94 ,41 ,13 ,61 ,13 ,67,
27 ,64 ,71 ,45 ,42 ,92 ,52 ,10 ,56 ,61,
28 ,95 ,44 ,74 ,53 ,97 ,81 ,69 ,87 ,14,
14 ,19 ,1 ,84 ,89 ,59 ,87 ,84 ,75 ,79;

	Hungarian hung(X);
	hung.doOptimize();
	RowVectorXf assignment = hung.rowAssignment;

	float cost = 0.0f;
	for (int r = 0; r < nRows; ++r) {
		int c = assignment[r];
		cost += X(r, c);
	}
	std::cout << "Cost = " << cost << std::endl;

	return 0;
}