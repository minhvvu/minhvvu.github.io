// DistanceUtils.h
// vvminh add Mahalanobis distance for one particule data set

#ifndef DISTANCETUILS_H_
#define DISTANCETUILS_H_

#include <eigen3/Eigen/Dense>
using namespace Eigen;

#include <cassert>

class DistanceUtils {
public:
	static MatrixXf covMatInv;

	static void calculateCovMat(const MatrixXf& X) {
		// std::cout << "Input data set: X " << X.rows() << "," << X.cols() << std::endl;
		VectorXf mu = X.rowwise().mean();
		// std::cout << "\nMean:\n" << mu << std::endl;
		MatrixXf X_aligned = X.colwise() - mu;
		// std::cout << "\nX_aligned:\n" << X_aligned << std::endl;
		MatrixXf covMat = X_aligned * X_aligned.transpose() / (X.cols() - 1);

		// full covMat
		covMatInv = covMat.inverse();

		// diagonal covMat
		// covMatInv = covMat.diagonal().asDiagonal().inverse();

		// std::cout << "CovMat Inv: " << covMatInv.rows() << "," << covMatInv.cols() << std::endl;
	}

	static float mahalanobis(const std::vector<float>& a, const std::vector<float>& b) {
		// assert(a.size() == b.size() && (int)a.size() == covMatInv.rows() );
		VectorXf va = VectorXf::Map(&a[0], a.size());
		VectorXf vb = VectorXf::Map(&b[0], b.size());
		return std::sqrt((va - vb).transpose() * covMatInv * (va - vb));
	}
};

MatrixXf DistanceUtils::covMatInv;

#endif