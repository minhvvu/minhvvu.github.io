//genSCC.cpp
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <utility>
#include <algorithm>
#include <cassert>

class LinkUtils {
public:
	LinkUtils() {}

	void readInput(std::string inputFileName) {
		std::ifstream infile(inputFileName.c_str());
		assert(infile.is_open() && "Can not open input file\n");
		
		infile >> nLinksOriginal;
		std::cout << "Read file " << inputFileName << ", has " << nLinksOriginal << " links\n";

		int p1 = 0, p2 = 0, type = 0, c1 = 0, c2 = 0;
		while (infile >> p1 >> c1 >> p2 >> c2 >> type) {
		// while (infile >> p1 >> p2 >> type) {
			std::pair<int, int> oneLink = (p1 < p2) ?
				std::make_pair(p1, p2) : std::make_pair(p2, p1);
			if (ML == type) {
				mustLinks.push_back(oneLink);
			} else if (CL == type){
				cannotLinks.push_back(oneLink);
			}
		}
		infile.close();
	}

	void autoDeduceLinks() {
		std::cout << "Labeling...";
		labelPointsInML();

		std::cout << "|\tReduce...";
		reduceLinks();

		int nRepeatMerge = findMaxKeyLength();
		std::cout << "|\tMergeKey need repeat  " << (nRepeatMerge + 1) << " times ... \n";
		for (int i = 0; i < (nRepeatMerge+1) / 2; ++i) {
			mergeComponentsByKey();
		}

		std::cout << "|\tGenML...";
		genAllMustLinks();

		std::cout << "|\tGenCL...";
		genAllCannotLinks();

		std::cout << "|\tDONE|\n";
	}

	void writeLinksToFile(std::string outputFileName) {
		std::ofstream outfile(outputFileName.c_str());
		if (!outfile.is_open()) {
			std::cerr << "Can not open " << outputFileName << std::endl;
			return;
		}
		
		int nLinksDeduced = (int)mustLinksGen.size() + (int)cannotLinksGen.size();
		outfile << nLinksOriginal << "\t" << nLinksDeduced << std::endl;
		
		for (const auto& it : mustLinksGen) {
			outfile << it.first << "\t" << it.second << "\t" << ML << "\n";
		}
		for (const auto& it : cannotLinksGen) {
			outfile << it.first << "\t" << it.second << "\t" << CL << "\n";
		}
		
		outfile.close();
	}

	void writeComponenetsToFile(std::string outputFileName) {
		std::ofstream outfile(outputFileName.c_str());
		if (!outfile.is_open()) {
			std::cerr << "Can not open " << outputFileName << std::endl;
			return;
		}
		for (const auto& it : components) {
			for (const int& p : it.second) {
				outfile << p << "\t";
			}
			outfile << std::endl;
		}
		outfile.close();
	}

private:
	void labelPointsInML() {
		for (const auto& it : mustLinks) {
			int p1 = it.first;
			bool p1Existed = labels.count(p1);
			if (!p1Existed) {
				labels[p1].push_back(getNextLabel());
			}
			int p2 = it.second;
			labels[p2].insert(labels[p2].end(), 
				labels[p1].begin(), labels[p1].end());
		}
	}

	void reduceLinks() {
		for (auto& it : labels) {
			std::set<int> keySet( it.second.begin(), it.second.end() );
			components[keySet].push_back(it.first);
		}
	}

	void mergeComponentsByKey() {
		std::map<std::set<int>, std::vector<int> > mergedComps;
		for (const auto& it : components) {
			std::set<int> target = keyToMerge(it.first);
			mergedComps[target].insert(
				mergedComps[target].end(),
				it.second.begin(), it.second.end()
			);
		}
		components = mergedComps;
	}

	void genAllMustLinks() {
		for (auto& it : components) {
			std::set<int> pointsLinked(it.second.begin(), it.second.end());
			it.second.assign(pointsLinked.begin(), pointsLinked.end());
			for (auto i = pointsLinked.begin(); i != pointsLinked.end(); ++i) {
				int id1 = *i;
				for (auto j = i; ++j != pointsLinked.end(); /**/) {
					int id2 = *j;
					mustLinksGen.push_back((id1 < id2)?
						std::make_pair(id1,id2) : std::make_pair(id2, id1));
				}
			}
		}
	}

	void genAllCannotLinks() {
		for (const auto& it : cannotLinks) {
			std::vector<int> comp1 = compContainsPoint(it.first);
			std::vector<int> comp2 = compContainsPoint(it.second);
			if (comp1.size() > 0 && comp2.size() > 0) {
			} else if (comp1.size() > 0) {
				populateCannotLinks(it.second, comp1);
			} else if (comp2.size() > 0) {
				populateCannotLinks(it.first, comp2);
			} else {
				populateCannotLinks(it.first, std::vector<int>{it.second});
			}
		}
	}

	std::vector<int> compContainsPoint(int p) {
		std::vector<int> comp;
		for (const auto& it : components) {
			if (std::find(it.second.begin(), it.second.end(), p) != it.second.end()) {
				comp = it.second;
				break;
			}
		}
		return comp;
	}

	void populateCannotLinks(int p1, const std::vector<int>& v) {
		for (const int& p2 : v) {
			cannotLinksGen.push_back((p1 < p2)?
				std::make_pair(p1,p2) : std::make_pair(p2, p1));
		}
	}

	std::set<int> keyToMerge(const std::set<int> baseKey) {
		std::set<int> bestKey;
		int maxSize =0;
		for (const int& elem : baseKey) {
			std::set<int> tempBestKey = longestKey(elem);
			if ((int)tempBestKey.size() > maxSize) {
				bestKey = tempBestKey;
				maxSize = bestKey.size();
			}
		}
		return bestKey;
	}

	std::set<int> longestKey(const int keyElem) {
		std::set<int> bestKey;
		int maxSize = 0;
		for (const auto& it : components) {
			if ( (int)it.first.size() > maxSize && it.first.count(keyElem) > 0 ) {
				bestKey = it.first;
				maxSize = bestKey.size();
			}
		}
		return bestKey;
	}

	int findMaxKeyLength() {
		int maxSize = 0;
		for (const auto& it : components) {
			maxSize = std::max((int)it.first.size(), maxSize );
		}
		return maxSize;
	}

	int getNextLabel() {
		currentLabel++;
		return currentLabel;
	}

private:
	void dumpLinks() {
		std::cout << "Links original: (ML = " << mustLinks.size()
			<< ", CL = " << cannotLinks.size() << ")\n";
		std::cout << "Links generated: (ML = " << mustLinksGen.size()
			<< ", CL = " << cannotLinksGen.size() << ")\n";
		std::cout << "Components size = " << components.size() << "\n";
	}

	void dumpLabels() {
		std::cout << "labels:\n";
		for (const auto& it : labels) {
			std::cout << it.first << ":{";
			for (const int& i : it.second) {
				std::cout << i << ", ";
			}
			std::cout << "}\n";
		}
	}

	void dumpComponents() {
		std::cout << "components:\n";
		for (const auto& it : components) {
			std::cout << "key={";
			for (const int& ikey : it.first) {
				std::cout << ikey << ", ";
			}
			std::cout << "} => value={";
			for (const int& ival : it.second) {
				std::cout << ival << ", ";
			}
			std::cout << "}\n";
		}
	}

private:
	std::vector<std::pair<int,int> > mustLinks;
	std::vector<std::pair<int,int> > mustLinksGen;
	std::vector<std::pair<int,int> > cannotLinks;
	std::vector<std::pair<int,int> > cannotLinksGen;
	std::map<int, std::vector<int> > labels;
	std::map<std::set<int>, std::vector<int> > components;

	static const int ML = 1;
	static const int CL = -1;

	int currentLabel = 0;
	int nLinksOriginal = 0;
};

std::string truncateExtension(std::string str) {
	std::string delimiter = ".";
	return str.substr(0, str.find(delimiter));
}

int main(int argc, char* argv[]) {
	if (4 != argc) {
		std::cerr << "Usage: ./genkLinks2 baseInputDir baseOutputDir inputFileName\n";
		return -1;
	}

	std::string baseInputDir = std::string(argv[1]);
	std::string baseOutputDir = std::string(argv[2]);
	std::string inputFileName = std::string(argv[3]);
	std::cout << "Processing file " << inputFileName << std::endl;

	LinkUtils linkUtils;
	linkUtils.readInput(baseInputDir + inputFileName);
	linkUtils.autoDeduceLinks();

	std::string sccFileName =  truncateExtension(inputFileName) + ".scc";
	std::string linksFileName = truncateExtension(inputFileName) + ".links";
	linkUtils.writeLinksToFile(baseOutputDir + linksFileName);
	linkUtils.writeComponenetsToFile(baseOutputDir + sccFileName);

	return 0;
}