// tools read data
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cassert>

#include <eigen3/Eigen/Dense>
using namespace Eigen;

std::vector<std::string> getListFileName(const std::string fileListName) {
	std::ifstream infile(fileListName.c_str());
	if (!infile.is_open()) {
		std::cerr << "Can not open list file " << fileListName << std::endl;
		exit(-1);
	}

	std::vector<std::string> listFile;
	int fileId = 0;
	std::string fileName = "";
	while (infile >> fileId >> fileName) {
        listFile.push_back(fileName);
	}
	infile.close();
	return listFile;
}

MatrixXf readListFileFromDir(std::string dirName, std::string fileExt, const std::vector<std::string>& listFile, int nDims) {
    int nSize = listFile.size();
    MatrixXf data (nDims, nSize);
    std::cout << "Read " << nSize << " files (" << nDims << " dimension) from " << dirName << std::endl;

    std::ifstream infile;
    float val = 0.0f;
    double debugSum = 0.0f;
    for(int i = 0; i < nSize; ++i) {
        std::string fileName = dirName + "/" + listFile.at(i) + "." + fileExt;
        infile.open(fileName.c_str());
        if (!infile.is_open()) {
            std::cerr << "Can not open file " << fileName << std::endl;
            continue;
        }
        int dimensions = 0;
        infile >> dimensions;
        if (nDims != dimensions) {
            std::cerr << "Dimensions in file " << fileName
                << " does not match with nDims = " << nDims << std::endl;
            infile.close();
            continue;
        }
        for (int d = 0; d < nDims; ++d) {
            infile >> val;
            debugSum += val;
            data(d, i) = val;
        }
        infile.close();
    }
    std::cout << "DEBUG SUM of all elems: " << debugSum << std::endl;
    return data;
}

void writeMatrixToFile(const MatrixXf& data, std::string dirName, std::string fileName) {
    int nRows = data.rows();
    int nCols = data.cols();
    std::string outName = dirName + "/" + fileName;
    std::cout << "Prepare to write matrix (dimensions = " << nRows << ", examples = " << nCols << ")"
        << "to outfile " << outName << std::endl;

    std::ofstream outfile(outName.c_str());
    if (!outfile.is_open()) {
        std::cerr << "Can not open file to write: " << outName << std::endl;
        return;
    }
    outfile << "dimensions\t" << nRows << "\texamples\t" << nCols << std::endl;
    outfile << data;
    outfile.close();
}

MatrixXf readMatrix(const std::string fileName) {
    MatrixXf mat;
    std::ifstream infile(fileName.c_str());
    if (!infile.is_open()) {
        std::cerr << "Can not open mat file: " << fileName << std::endl;
        return mat;
    }
    std::string keyName;
	int nExamples = 0;
	int nDimensions = 0;
	float val = 0.0f;
	infile >> keyName >> nDimensions >> keyName >> nExamples;
	mat = MatrixXf(nDimensions, nExamples);

	for (int dim = 0; dim < nDimensions; ++dim) {
		for (int exampleIdx = 0; exampleIdx < nExamples; ++exampleIdx) {
			infile >> val;
			mat(dim, exampleIdx) = val;
		}
	}
	std::cout << "CHECK SUM = " << mat.sum() << std::endl;
    return mat;
}

std::string buildMatrixFromFile(std::string rootDir,  std::string rawDataDir, std::string fileExt,
       std::string outFileName,  std::string fileId, int codebookSize) {
    std::string fileListPath = rootDir + "/" + fileId;
    std::vector<std::string> listFile = getListFileName(fileListPath);

    std::string rawDataPath = rootDir + "/" + rawDataDir + std::to_string(codebookSize);
    MatrixXf data = readListFileFromDir(rawDataPath, fileExt, listFile, codebookSize);

    std::string outFileFullName = outFileName + "_" + std::to_string(codebookSize) + ".mat";
    writeMatrixToFile(data, rootDir, outFileFullName);

	return outFileFullName;
}

int main(int argc, char* argv[]) {
    std::string rootDir = "/home/vvminh/WorkData/PascalVoc2006";
    std::string rawDataDir = "rgSIFT/rgSIFT_";
    std::string fileExt = "txt";
    std::string outFileName = "Pascal";
    std::string fileId = "IdPascal.txt";

	// 	rootDir = "/home/vvminh/WorkData/Wang";
	// 	outFileName = "Wang";
	//     fileId = "IdWang.txt";

    std::string resultFileName = buildMatrixFromFile(rootDir, rawDataDir, fileExt, outFileName, fileId, 50);
	MatrixXf mat = readMatrix(rootDir + "/" + resultFileName);
}
