#include <iostream>
#include <fstream>
#include <stdexcept>

int main() {
    std::string outFileName = "/home/vvminh/WorkData/Wang/WangGroundTruth.txt";
    std::ofstream outFile(outFileName.c_str());
    if (!outFile.is_open()) {
        throw std::runtime_error("Can not open file to write: " + outFileName);
    }
    outFile << 10 << "\n";
    for (int i = 0; i < 1000; ++i) {
        outFile << i << "\t" << (int)(i / 100) << "\n";
    }
    outFile.close();
    return 0;
}
