// genConstraints.cpp
#include <iostream>
#include <random>
#include <iostream>
#include <string>
#include <fstream>
#include <stdexcept>
#include <vector>
#include <map>
#include <tuple>
#include <cassert>

/**
 * global vars to control random generator
 */

int nClasses = 0;

// http://stackoverflow.com/questions/19665818/best-way-to-generate-random-numbers-using-c11-random-library
const int factor = 10000;
std::random_device rd;
std::mt19937 mt(rd());
std::uniform_real_distribution<float> dist(0, factor);
// usage: std::cout << dist(mt) << "\n";

// prepare params
float pNotSelected = 0.95f;
float pML = 0.92f;
float pCL = 0.98f;

std::string groundTruthFileName = "../PascalVoc2006/PascalGroundTruth.txt";
std::string outputBaseName = "../PascalVoc2006/constraints_original/";

// std::string groundTruthFileName = "../Wang/WangGroundTruth.txt";
// std::string outputBaseName = "../Wang/constraints_original/";

typedef std::map<int, std::vector<int> > MapDataByClass_t;
MapDataByClass_t listData;
std::vector<std::uniform_real_distribution<float> > listDist;
std::vector<int> groundTruth;

////////////////////////////////////////////////////////////////////////////////
// utils functions

/**
 *  create a map: map[classId] => list_of_data_in_this_class
 */
MapDataByClass_t assignDataToClass(const std::vector<int>& vData, int nClasses) {
    MapDataByClass_t listData;
    for (int i =0; i < nClasses; ++i) {
        listData[i] = std::vector<int>();
    }

    for (int idx = 0; idx < (int)vData.size(); ++idx) {
        int classId = vData.at(idx);
        listData.at(classId).push_back(idx);
    }

    return listData;
}


bool isSelected() {
    return dist(mt) > (pNotSelected * factor);
}

bool isMLSelected() {
    return dist(mt) > (pML * factor);
}

bool isCLSelected() {
    return dist(mt) > (pCL * factor);
}

int randomPoint(int classId) {
    int randomIndex = (int)(listDist.at(classId))(mt);
    randomIndex = std::min(randomIndex, (int)listData.at(classId).size() - 1);
    return listData.at(classId).at(randomIndex);
}


/**
 * read ground truth file into a vector: grouthTruth[imageId] = classId
 * the number of ground truth classes is assigned to in-out param nClasses
 */
std::vector<int> readGroundTruth(const std::string fileName, int& nClasses) {
    std::ifstream infile(fileName.c_str());
    if (!infile.is_open()) {
        throw std::runtime_error("Unable to open grouth truth file: " + fileName);
    }

    // read number of grouth truth class
    infile >> nClasses;

    // build grouth truth label: grouthTruth[imageId] = classId
    std::vector<int> grouthTruth;
    int idx = 0, classId = 0;
    while (infile >> idx >> classId) {
        grouthTruth.push_back(classId);
    }
    infile.close();
    return grouthTruth;
}

void writeResulToFile(const std::vector<std::tuple<int, int, int, int, int> >& generatedLinks) {
    std::string outputFileName = outputBaseName + std::to_string(generatedLinks.size()) + ".txt";
    std::ofstream outfile(outputFileName.c_str());
    if (!outfile.is_open()) {
        std::cerr << "Can not open outputFileName " << outputFileName << std::endl;
        return;
    }

    outfile << generatedLinks.size() << "\n";
    for (const auto& it : generatedLinks) {
        int link1 = std::get<0>(it);
        int class1 = std::get<1>(it); 
        int link2 = std::get<2>(it);
        int class2 = std::get<3>(it); 
        int linkType = std::get<4>(it);
        outfile << link1 << "\t" << class1 << "\t" << link2 << "\t" << class2 << "\t" << linkType << "\n";
    }
    outfile.close();
}

/**
 *  generate links and return the number of links generated
 */
int doGenerateConstraintFile() {
    std::vector<std::tuple<int, int, int, int, int> > generatedLinks;
    int countML = 0;
    for (int class1 = 0; class1 < nClasses; ++class1) {
        for (int idx1 = 0; idx1 < (int)listData.at(class1).size(); ++idx1) {
            if (!isSelected()) {continue;}

            for (int class2 = 0; class2 < nClasses; ++class2) {
                for (int idx2 = 0; idx2 < (int)listData.at(class2).size(); ++idx2) {
                    if (!isSelected()) {continue;}
                    
                    int link1 = randomPoint(class1);
                    int link2 = randomPoint(class2);

                    int linkType = (class1==class2)?1:-1;
                    int linkCorrect = (groundTruth[link1]==groundTruth[link2])?1:-1;
                    assert(linkCorrect==linkType && "Error gen link!");

                    bool condition = (1 == linkType && isMLSelected()) ||
                                     (-1 == linkType && isCLSelected());
                    if (condition) {
                        generatedLinks.push_back(std::make_tuple(
                            link1, class1, link2, class2, linkType
                        ));
                        countML += (1==linkType)?1:0;
                    }
                }
            }
        }
    }

    int nData = groundTruth.size();
    std::cout << "number of generated link: " << generatedLinks.size() << ", ml = " << countML
        << "\tpercent = " << (1.0 * generatedLinks.size() / (nData * nData) * 100) << "\n";

    writeResulToFile(generatedLinks);
    return (int)generatedLinks.size();
}

int main() {
    // step1: get ground truth of target database
    groundTruth = readGroundTruth(groundTruthFileName, nClasses);
    listData = assignDataToClass(groundTruth, nClasses);

    std::cout << "Count data in each classes:\n";
    for (const auto& it : listData) {
        std::cout << "classId " << it.first << "\tnCount = " << it.second.size() << "\n";
    }

    // step2: create a list of random distribution according to the number of elems of each class
    // the goal is to enable to pick randomly one datapoint from each class
    for (const auto& it : listData) {
        int elemCount = it.second.size();
        listDist.push_back(std::uniform_real_distribution<float>(0, elemCount));
    }

    for (pNotSelected = 0.7; pNotSelected < 0.9; pNotSelected += 0.05) {
        std::cout << "gen links with pNotSelected = " << pNotSelected << ":";
        doGenerateConstraintFile();
    }

    std::cout << "Code done.\n";
	return 0;
}