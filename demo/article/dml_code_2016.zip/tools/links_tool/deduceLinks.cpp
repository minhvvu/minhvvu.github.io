#include <iostream>
#include <algorithm>    // std::find
#include <fstream>
#include <map>
#include <utility>
#include <string>
#include <chrono>

#include "graphUtils.h"

const int MUST_LINK = 1;
const int CANNOT_LINK = -1;

int nConstraintsOriginal = 0;
int nConstraintsDeduced = 0;

std::map<int, int> mapDataIdToVertex;
std::map<int, int> mapVertexToDataId;
std::map<std::pair<int, int>, int> allLinks;
std::vector<std::vector<int> > connectedComponents; // strongly connected components

void buildConstraints(std::string inputFileName);
void readConstraintsFromFile(std::string fileName);
void dumpAllLinks();
void buildMapId();
void dumpMapId();
void writeSCCToFile(std::string outputFileName);
void genML(const std::vector<std::pair<int, int> >& generatedMustLinks);
void genCL();
std::vector<int> componentThatContains(int dataId);
void writeAllLinksToFile(std::string outputFileName);

std::string truncateExtension(std::string str) {
	// http://stackoverflow.com/questions/14265581/parse-split-a-string-in-c-using-string-delimiter-standard-c
	std::string delimiter = ".";
	return str.substr(0, str.find(delimiter));
}

int main(int argc, char* argv[]) {
	if (4 != argc) {
		std::cerr << "Usage: ./deduceLinks baseInputDir baseOutputDir inputFileName\n";
		return -1;
	}

	std::string baseInputDir = std::string(argv[1]); // "/home/vvminh/WorkData/Wang/constraints_original/";
	std::string baseOutputDir = std::string(argv[2]); // "/home/vvminh/WorkData/Wang/constraints_deduced/";
	std::string inputFileName = std::string(argv[3]); // "1112.txt";
	std::string sccFileName =  truncateExtension(inputFileName) + ".scc";
	std::string deducedFileName = truncateExtension(inputFileName) + ".links";

	std::cout << "Processing file " << inputFileName << std::endl;
	buildConstraints(baseInputDir + inputFileName);
	// std::cout << "Write SCC to : " << sccFileName << std::endl;
	writeSCCToFile(baseOutputDir + sccFileName);
	// std::cout << "Write links to : " << deducedFileName << std::endl;
	writeAllLinksToFile(baseOutputDir + deducedFileName);
}

void buildConstraints(std::string inputFileName) {
	readConstraintsFromFile(inputFileName);
	buildMapId();

	using namespace std::chrono;
	high_resolution_clock::time_point t1;
	auto duration = 0.0f;

	int nNodes = (int)mapDataIdToVertex.size();
	std::cout << "Create graph with " << nNodes << " nodes...";
	t1 = high_resolution_clock::now();
		Graph* g = new Graph(nNodes);
		for (const auto& it : allLinks) {
			if (MUST_LINK == it.second) {
				int nodeA = mapDataIdToVertex[it.first.first];
				int nodeB = mapDataIdToVertex[it.first.second];
				g->addEdge(nodeA, nodeB);
			}
		}
	duration = std::chrono::duration_cast<std::chrono::milliseconds>( high_resolution_clock::now() - t1 ).count();
	std::cout << "\t" << duration << std::endl;

	std::cout << "Build buildTransitiveClosure...";
	t1 = high_resolution_clock::now();
		g->buildTransitiveClosure();
	duration = std::chrono::duration_cast<std::chrono::milliseconds>( high_resolution_clock::now() - t1 ).count();
	std::cout << "\t" << duration << std::endl;

	std::cout << "Build buildAdjacencyLists...";
	t1 = high_resolution_clock::now();
		g->buildAdjacencyLists();
	duration = std::chrono::duration_cast<std::chrono::milliseconds>( high_resolution_clock::now() - t1 ).count();
	std::cout << "\t" << duration << std::endl;

	std::cout << "Calculate Strongly Connected Components...";
	t1 = high_resolution_clock::now();
		g->SCC();
	duration = std::chrono::duration_cast<std::chrono::milliseconds>( high_resolution_clock::now() - t1 ).count();
	std::cout << "\t" << duration << std::endl;

	connectedComponents = g->getConnectedComponents();

	std::cout << "Deduce ML...";
	t1 = high_resolution_clock::now();
		genML(g->getLinksInTransitiveClosure());
	duration = std::chrono::duration_cast<std::chrono::milliseconds>( high_resolution_clock::now() - t1 ).count();
	std::cout << "\t" << duration << std::endl;


	std::cout << "Deduce CL...";
	t1 = high_resolution_clock::now();
		genCL();
	duration = std::chrono::duration_cast<std::chrono::milliseconds>( high_resolution_clock::now() - t1 ).count();
	std::cout << "\t" << duration << std::endl;

	delete g;
}


void readConstraintsFromFile(std::string fileName) {
	std::ifstream infile(fileName.c_str());
	if (!infile.is_open()) {
		std::cerr << "Can not open constraint file: " << fileName << std::endl;
		return;
	}

	allLinks.clear();
	int idx1 = 0, classA = 0, idx2 = 0, classB = 0, linkType = 0;
	infile >> nConstraintsOriginal;
	for (int i = 0; i < nConstraintsOriginal; ++i) {
		infile >> idx1 >> classA >> idx2 >> classB >> linkType;
		std::pair<int, int> newPair = (idx1 < idx2) ? 
			std::make_pair(idx1, idx2) : std::make_pair(idx2, idx1);
		allLinks[newPair] = linkType;
		
		// get unique list of node Id
		mapDataIdToVertex[idx1] = 1;
		mapDataIdToVertex[idx2] = 1;
	}

	infile.close();
}

void buildMapId() {
	int nodeId = 0;
	for (auto& it : mapDataIdToVertex) {
		it.second = nodeId;
		mapVertexToDataId[nodeId] = it.first;
		nodeId++;
	}
}

void dumpMapId() {
	// test dump map
	std::cout << "mapDataIdToVertex\n";
	for (const auto& it : mapDataIdToVertex) {
		std::cout << it.first << " => " << it.second << "\n";
	}

	std::cout << "mapVertexToDataId\n";
	for (const auto& it : mapVertexToDataId) {
		std::cout << it.first << " => " << it.second << "\n";
	}
}

void writeSCCToFile(std::string outputFileName) {
	std::ofstream outfile(outputFileName.c_str());
	if (!outfile.is_open()) {
		std::cerr << "Can not open outputFileName: " << outputFileName << std::endl;
		return;
	}

	for (const auto& comp : connectedComponents) {
		for (const int& id : comp) {
			outfile << mapVertexToDataId[id] << "\t";
		}
		outfile << std::endl;
	}

	outfile.close();
}

void genML(const std::vector<std::pair<int, int> >& generatedMustLinks) {
	for (const auto& onePair : generatedMustLinks) {
		int nodeA = onePair.first;
		int nodeB = onePair.second;
		int idx1 = mapVertexToDataId[nodeA];
		int idx2 = mapVertexToDataId[nodeB];
		std::pair<int, int> newPair = (idx1 < idx2) ? std::make_pair(idx1, idx2) : std::make_pair(idx2, idx1);
		allLinks[newPair] = MUST_LINK;
	}
	nConstraintsDeduced = (int)allLinks.size();
}

void genCL() {
	for (auto& it : allLinks) {
		if (MUST_LINK == it.second) continue;

		int idx1 = it.first.first;
		int idx2 = it.first.second;

		std::vector<int> containA = componentThatContains(idx1);
		if (containA.empty()) continue;
		std::vector<int> containB = componentThatContains(idx2);
		if (containB.empty()) continue;

		for (const auto& nodeA : containA) {
			int idxA = mapVertexToDataId[nodeA];
			for (const auto& nodeB : containB) {
				int idxB = mapVertexToDataId[nodeB];
				std::pair<int, int> newLink = (idxA < idxB) ?
					std::make_pair(idxA, idxB) : std::make_pair(idxB, idxA);
				allLinks[newLink] = CANNOT_LINK;
			}
		}
	}
	nConstraintsDeduced = (int)allLinks.size();
}

std::vector<int> componentThatContains(int dataId) {
	int nodeId = mapDataIdToVertex[dataId];
	std::vector<int> result;
	for (const auto& oneComp : connectedComponents) {
		if (std::find(oneComp.begin(), oneComp.end(), nodeId) != oneComp.end()) {
			result = oneComp;
			break;
		}
	}
	return result;
}

void dumpAllLinks() {
	std::cout << std::endl << "All constraints: " << std::endl;
	int nML = 0;
	int nCL = 0;
	for (const auto& it : allLinks) {
		if (MUST_LINK == it.second) {
			nML ++;
		} else if (CANNOT_LINK == it.second) {
			nCL ++;
		}
	}
	std::cout << "nML = " << nML << ", nCL = " << nCL << ", sum = " << allLinks.size() << std::endl;
}

void writeAllLinksToFile(std::string outputFileName) {
	std::ofstream outfile(outputFileName.c_str());
	if (!outfile.is_open()) {
		std::cerr << "Can not open outputFileName: " << outputFileName << std::endl;
		return;
	}
	outfile << nConstraintsOriginal << "\t" << nConstraintsDeduced << "\n";
	for (const auto& it : allLinks) {
		outfile << it.first.first << "\t" << it.first.second << "\t" << it.second << "\n";
	}

	outfile.close();
}