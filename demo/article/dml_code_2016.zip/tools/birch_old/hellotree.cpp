// hellotree.cpp

#include <iostream>
#include <string>
#include <algorithm>
#include "tree.hh"
#include "tree_util.hh"


int main() {
	std::cout << "Hello tree!\n\n";

	tree<std::string> tr;

	auto top = tr.begin();
	auto one = tr.insert(top, "ONE");
	tr.insert(top, "TWO");
	tr.insert(top, "TREE");
	
	tr.append_child(one, "XXX");
	tr.append_child(one, "YYY");
	tr.append_child(one, "ZZZ");


	kptree::print_tree_bracketed(tr);

	std::cout << "\nnum child of top: " << tr.number_of_children(top);
	std::cout << "\nnum child of one: " << tr.number_of_children(one);

	std::cout << "\nTry to print leaf node:\n";
	for (auto leafit = tr.begin_leaf(); leafit != tr.end_leaf(); ++leafit) {
		std::cout << (*leafit) << "\t";
	}

	std::cout << "\n\nEnd code\n";
	return 0;
}

/**

		/// Return iterator to the beginning of the tree.
		inline pre_order_iterator   begin() const;
		/// Return iterator to the end of the tree.
		inline pre_order_iterator   end() const;
		/// Return post-order iterator to the beginning of the tree.
		post_order_iterator  begin_post() const;
		/// Return post-order end iterator of the tree.
		post_order_iterator  end_post() const;
		/// Return fixed-depth iterator to the first node at a given depth from the given iterator.
		fixed_depth_iterator begin_fixed(const iterator_base&, unsigned int) const;
		/// Return fixed-depth end iterator.
		fixed_depth_iterator end_fixed(const iterator_base&, unsigned int) const;
		/// Return breadth-first iterator to the first node at a given depth.
		breadth_first_queued_iterator begin_breadth_first() const;
		/// Return breadth-first end iterator.
		breadth_first_queued_iterator end_breadth_first() const;
		/// Return sibling iterator to the first child of given node.
		sibling_iterator     begin(const iterator_base&) const;
		/// Return sibling end iterator for children of given node.
		sibling_iterator     end(const iterator_base&) const;
      /// Return leaf iterator to the first leaf of the tree.
      leaf_iterator   begin_leaf() const;
      /// Return leaf end iterator for entire tree.
      leaf_iterator   end_leaf() const;
      /// Return leaf iterator to the first leaf of the subtree at the given node.
      leaf_iterator   begin_leaf(const iterator_base& top) const;
      /// Return leaf end iterator for the subtree at the given node.
      leaf_iterator   end_leaf(const iterator_base& top) const;

		/// Return iterator to the parent of a node.
		template<typename	iter> static iter parent(iter);
		/// Return iterator to the previous sibling of a node.
		template<typename iter> static iter previous_sibling(iter);
		/// Return iterator to the next sibling of a node.
		template<typename iter> static iter next_sibling(iter);
		/// Return iterator to the next node at a given depth.
		template<typename iter> iter next_at_same_depth(iter) const;

		/// Erase all nodes of the tree.
		void     clear();
		/// Erase element at position pointed to by iterator, return incremented iterator.
		template<typename iter> iter erase(iter);
		/// Erase all children of the node pointed to by iterator.
		void     erase_children(const iterator_base&);

		/// Insert empty node as last/first child of node pointed to by position.
		template<typename iter> iter append_child(iter position); 
		template<typename iter> iter prepend_child(iter position); 
		/// Insert node as last/first child of node pointed to by position.
		template<typename iter> iter append_child(iter position, const T& x);
		template<typename iter> iter prepend_child(iter position, const T& x);
		/// Append the node (plus its children) at other_position as last/first child of position.
		template<typename iter> iter append_child(iter position, iter other_position);
		template<typename iter> iter prepend_child(iter position, iter other_position);
		/// Append the nodes in the from-to range (plus their children) as last/first children of position.
		template<typename iter> iter append_children(iter position, sibling_iterator from, sibling_iterator to);
		template<typename iter> iter prepend_children(iter position, sibling_iterator from, sibling_iterator to);

		/// Short-hand to insert topmost node in otherwise empty tree.
		pre_order_iterator set_head(const T& x);
		/// Insert node as previous sibling of node pointed to by position.
		template<typename iter> iter insert(iter position, const T& x);
		/// Specialisation of previous member.
		sibling_iterator insert(sibling_iterator position, const T& x);
		/// Insert node (with children) pointed to by subtree as previous sibling of node pointed to by position.
		/// Does not change the subtree itself (use move_in or move_in_below for that).
		template<typename iter> iter insert_subtree(iter position, const iterator_base& subtree);
		/// Insert node as next sibling of node pointed to by position.
		template<typename iter> iter insert_after(iter position, const T& x);
		/// Insert node (with children) pointed to by subtree as next sibling of node pointed to by position.
		template<typename iter> iter insert_subtree_after(iter position, const iterator_base& subtree);

		/// Replace node at 'position' with other node (keeping same children); 'position' becomes invalid.
		template<typename iter> iter replace(iter position, const T& x);
		/// Replace node at 'position' with subtree starting at 'from' (do not erase subtree at 'from'); see above.
		template<typename iter> iter replace(iter position, const iterator_base& from);
		/// Replace string of siblings (plus their children) with copy of a new string (with children); see above
		sibling_iterator replace(sibling_iterator orig_begin, sibling_iterator orig_end, 
										 sibling_iterator new_begin,  sibling_iterator new_end); 

		/// Move all children of node at 'position' to be siblings, returns position.
		template<typename iter> iter flatten(iter position);
		/// Move nodes in range to be children of 'position'.
		template<typename iter> iter reparent(iter position, sibling_iterator begin, sibling_iterator end);
		/// Move all child nodes of 'from' to be children of 'position'.
		template<typename iter> iter reparent(iter position, iter from);

		/// Replace node with a new node, making the old node a child of the new node.
		template<typename iter> iter wrap(iter position, const T& x);

		/// Move 'source' node (plus its children) to become the next sibling of 'target'.
		template<typename iter> iter move_after(iter target, iter source);
		/// Move 'source' node (plus its children) to become the previous sibling of 'target'.
      template<typename iter> iter move_before(iter target, iter source);
      sibling_iterator move_before(sibling_iterator target, sibling_iterator source);
		/// Move 'source' node (plus its children) to become the node at 'target' (erasing the node at 'target').
		template<typename iter> iter move_ontop(iter target, iter source);

		/// Extract the subtree starting at the indicated node, removing it from the original tree.
		tree                         move_out(iterator);
		/// Inverse of take_out: inserts the given tree as previous sibling of indicated node by a 
		/// move operation, that is, the given tree becomes empty. Returns iterator to the top node.
		template<typename iter> iter move_in(iter, tree&);
		/// As above, but now make the tree a child of the indicated node.
		template<typename iter> iter move_in_below(iter, tree&);
		/// As above, but now make the tree the nth child of the indicated node (if possible).
		template<typename iter> iter move_in_as_nth_child(iter, size_t, tree&);

		/// Merge with other tree, creating new branches and leaves only if they are not already present.
		void     merge(sibling_iterator, sibling_iterator, sibling_iterator, sibling_iterator, 
							bool duplicate_leaves=false);
		/// Sort (std::sort only moves values of nodes, this one moves children as well).
		void     sort(sibling_iterator from, sibling_iterator to, bool deep=false);
		template<class StrictWeakOrdering>
		void     sort(sibling_iterator from, sibling_iterator to, StrictWeakOrdering comp, bool deep=false);
		/// Compare two ranges of nodes (compares nodes as well as tree structure).
		template<typename iter>
		bool     equal(const iter& one, const iter& two, const iter& three) const;
		template<typename iter, class BinaryPredicate>
		bool     equal(const iter& one, const iter& two, const iter& three, BinaryPredicate) const;
		template<typename iter>
		bool     equal_subtree(const iter& one, const iter& two) const;
		template<typename iter, class BinaryPredicate>
		bool     equal_subtree(const iter& one, const iter& two, BinaryPredicate) const;
		/// Extract a new tree formed by the range of siblings plus all their children.
		tree     subtree(sibling_iterator from, sibling_iterator to) const;
		void     subtree(tree&, sibling_iterator from, sibling_iterator to) const;
		/// Exchange the node (plus subtree) with its sibling node (do nothing if no sibling present).
		void     swap(sibling_iterator it);
		/// Exchange two nodes (plus subtrees)
	   void     swap(iterator, iterator);
		
		/// Count the total number of nodes.
		size_t   size() const;
		/// Count the total number of nodes below the indicated node (plus one).
		size_t   size(const iterator_base&) const;
		/// Check if tree is empty.
		bool     empty() const;
		/// Compute the depth to the root or to a fixed other iterator.
		static int depth(const iterator_base&);
		static int depth(const iterator_base&, const iterator_base&);
		/// Determine the maximal depth of the tree. An empty tree has max_depth=-1.
		int      max_depth() const;
		/// Determine the maximal depth of the tree with top node at the given position.
		int      max_depth(const iterator_base&) const;
		/// Count the number of children of node at position.
		static unsigned int number_of_children(const iterator_base&);
		/// Count the number of siblings (left and right) of node at iterator. Total nodes at this level is +1.
		unsigned int number_of_siblings(const iterator_base&) const;
		/// Determine whether node at position is in the subtrees with root in the range.
		bool     is_in_subtree(const iterator_base& position, const iterator_base& begin, 
									  const iterator_base& end) const;
		/// Determine whether the iterator is an 'end' iterator and thus not actually pointing to a node.
		bool     is_valid(const iterator_base&) const;
		/// Find the lowest common ancestor of two nodes, that is, the deepest node such that
		/// both nodes are descendants of it.
		iterator lowest_common_ancestor(const iterator_base&, const iterator_base &) const;

		/// Determine the index of a node in the range of siblings to which it belongs.
		unsigned int index(sibling_iterator it) const;
		/// Inverse of 'index': return the n-th child of the node at position.
		static sibling_iterator child(const iterator_base& position, unsigned int);
		/// Return iterator to the sibling indicated by index
		sibling_iterator sibling(const iterator_base& position, unsigned int);  				
		
		/// For debugging only: verify internal consistency by inspecting all pointers in the tree
		/// (which will also trigger a valgrind error in case something got corrupted).
		void debug_verify_consistency() const;
		

*/				