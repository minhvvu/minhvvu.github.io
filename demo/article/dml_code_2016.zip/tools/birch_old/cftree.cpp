// cftree.cpp

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include "tree.hh"
#include "tree_util.hh"

#include <eigen3/Eigen/Dense>
using namespace Eigen;

const int NDIM = 2;

template<int dim> 
class CFEntity {
public:
	int N;
	VectorXf LS;
	VectorXf SS;

	CFEntity() : N{0} {
		LS.setZero(dim);
		SS.setZero(dim);
	}

	void dump() {
		std::cout << "LS:[" << LS.transpose() << "]\n";
		std::cout << "SS:[" << SS.transpose() << "]\n";
	}
};

template<int dim>
class CFEntityLeaf : public CFEntity<dim> {
public:		
	std::vector<int> listIdx;

	bool canAbsorb(const VectorXf& v) {
		return true;
	}

	void absorb(const VectorXf& v, int idx) {
		listIdx.push_back(idx);
		LS += v;
		SS += v.array().square();
	}

	void dump() {
		CFEntity<dim>::dump();
		std::cout << "list Index: [";
		for (const int& idx : listIdx) std::cout << idx << ",";
		std::cout << "]\n";
	}
};

typedef CFEntity<NDIM> Node_t;

class CFTree {

	tree<Node_t> tr;

public:

	CFTree() {
		Node_t top;
	}

	void insert(const VectorXf& v, int idx) {
		
	}

	void printTree() {
		auto it = tr.begin();
		int rootDepth = tr.depth(it);
		std::cout << "CF Tree rootDepth = " << rootDepth << '\n';
		while (it != tr.end()) {
			it->dump();
			it++;
		}
	}
};

int main() {

	MatrixXf m(2, 10);
	m << 	1, 1, 2, 2, 2, 4, 4, 5, 6, 7,
			2, 1, 3, 2, 1, 4, 2, 3, 6, 5;
	std::cout << "input data: \n" << m << std::endl;


	return 0;
}